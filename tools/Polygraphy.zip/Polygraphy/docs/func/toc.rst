================
Function Helpers
================

Module: ``polygraphy.func``

.. automodule:: polygraphy.func.func
