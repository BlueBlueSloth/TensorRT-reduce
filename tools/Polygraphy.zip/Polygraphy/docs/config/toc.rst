=====================
Global Configuration
=====================

Module: ``polygraphy.config``

.. automodule:: polygraphy.config
