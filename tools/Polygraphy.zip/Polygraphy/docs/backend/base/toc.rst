===============
Base Interface
===============

The base interface for all loaders and runners.

Module: ``polygraphy.backend.base``

.. toctree::
    loader
    runner
