============
Runners
============

Module: ``polygraphy.backend.base``

.. automodule:: polygraphy.backend.base.runner
