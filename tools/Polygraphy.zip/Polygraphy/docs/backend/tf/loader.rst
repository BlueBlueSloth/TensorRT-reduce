============
Loaders
============

Module: ``polygraphy.backend.tf``

.. automodule:: polygraphy.backend.tf.loader
    :inherited-members:
