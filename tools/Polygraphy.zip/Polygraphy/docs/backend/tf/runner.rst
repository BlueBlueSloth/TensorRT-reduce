============
Runners
============

Module: ``polygraphy.backend.tf``

.. automodule:: polygraphy.backend.tf.runner
    :inherited-members:
