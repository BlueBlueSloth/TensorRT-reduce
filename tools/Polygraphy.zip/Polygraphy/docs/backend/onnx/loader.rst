============
Loaders
============

Module: ``polygraphy.backend.onnx``

.. automodule:: polygraphy.backend.onnx.loader
    :inherited-members:
