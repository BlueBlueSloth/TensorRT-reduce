============
Runners
============

Module: ``polygraphy.backend.pluginref``

.. automodule:: polygraphy.backend.pluginref.runner
    :inherited-members:
