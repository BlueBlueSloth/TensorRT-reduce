================
Plugin Reference
================

Module: ``polygraphy.backend.pluginref``

.. toctree::
    runner
