============
Runners
============

Module: ``polygraphy.backend.onnxrt``

.. automodule:: polygraphy.backend.onnxrt.runner
    :inherited-members:
