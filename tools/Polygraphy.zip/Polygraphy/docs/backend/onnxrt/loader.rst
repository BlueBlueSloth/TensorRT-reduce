============
Loaders
============

Module: ``polygraphy.backend.onnxrt``

.. automodule:: polygraphy.backend.onnxrt.loader
    :inherited-members:
