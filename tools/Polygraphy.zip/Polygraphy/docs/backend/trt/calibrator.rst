============
Calibrator
============

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.calibrator
