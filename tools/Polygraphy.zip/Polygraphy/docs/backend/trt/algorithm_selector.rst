==================
Algorithm Selector
==================

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.algorithm_selector
