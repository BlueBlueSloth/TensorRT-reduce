====================
Optimization Profile
====================

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.profile
