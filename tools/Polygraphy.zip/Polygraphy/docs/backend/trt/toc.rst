=========
TensorRT
=========

Module: ``polygraphy.backend.trt``

.. toctree::
    algorithm_selector
    calibrator
    loader
    profile
    runner
    util
