============
Loaders
============

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.loader
    :inherited-members:
    :exclude-members: polygraphy.backend.trt.loader.BaseNetworkFromOnnx
