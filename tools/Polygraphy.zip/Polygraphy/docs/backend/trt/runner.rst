============
Runners
============

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.runner
    :inherited-members:
