============
Utilities
============

Module: ``polygraphy.backend.trt``

.. automodule:: polygraphy.backend.trt.util
