========
Backends
========

Module: ``polygraphy.backend``

.. toctree::
    base/toc
    common/toc
    onnx/toc
    onnxrt/toc
    pluginref/toc
    tf/toc
    trt/toc
