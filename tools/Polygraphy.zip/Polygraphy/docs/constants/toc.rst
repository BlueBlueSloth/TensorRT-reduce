================
Constants
================

Module: ``polygraphy.constants``

.. automodule:: polygraphy.constants
