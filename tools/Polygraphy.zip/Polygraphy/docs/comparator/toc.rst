==================
Comparing Results
==================

Module: ``polygraphy.comparator``

.. toctree::
    comparator
    data_structures
    compare_func
    postprocess_func
    data_loader
