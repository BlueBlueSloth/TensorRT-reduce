===========
Data Loader
===========

Module: ``polygraphy.comparator``

.. automodule:: polygraphy.comparator.data_loader
