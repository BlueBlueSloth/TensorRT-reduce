====================
Comparison Functions
====================

Module: ``polygraphy.comparator``

.. automodule:: polygraphy.comparator.compare
