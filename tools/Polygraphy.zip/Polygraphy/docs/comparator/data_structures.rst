================
Data Structures
================

Module: ``polygraphy.comparator``

.. automodule:: polygraphy.comparator.struct
