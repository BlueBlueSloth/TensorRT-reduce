==========
Exceptions
==========

Module: ``polygraphy.exception``

.. automodule:: polygraphy.exception.exception
