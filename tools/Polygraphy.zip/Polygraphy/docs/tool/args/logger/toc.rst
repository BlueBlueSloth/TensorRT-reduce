============
Logger
============

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.logger.logger
