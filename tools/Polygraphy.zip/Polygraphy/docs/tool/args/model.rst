=========================
Model
=========================

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.model
