========
Backends
========

Module: ``polygraphy.tools.args``

.. toctree::
    onnx/toc
    onnxrt/toc
    pluginref/toc
    tf/toc
    trt/toc
