============
Loaders
============

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.backend.tf.loader

.. automodule:: polygraphy.tools.args.backend.tf.config
