============
Runners
============

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.backend.tf.runner
