=========================
Base Interface
=========================

The base interface for all argument groups.

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.base
