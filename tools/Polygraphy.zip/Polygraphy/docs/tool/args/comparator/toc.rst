=============
Comparator
=============

Module: ``polygraphy.tools.args``

.. toctree::
    comparator
    compare
    data_loader
    postprocess
