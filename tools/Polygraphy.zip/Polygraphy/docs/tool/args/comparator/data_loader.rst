============
Data Loader
============

Module: ``polygraphy.tools.args``

.. automodule:: polygraphy.tools.args.comparator.data_loader
