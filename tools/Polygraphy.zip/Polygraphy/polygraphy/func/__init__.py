from polygraphy.func.func import *
