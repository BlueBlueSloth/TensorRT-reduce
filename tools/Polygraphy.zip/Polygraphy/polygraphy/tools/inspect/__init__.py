from polygraphy.tools.inspect.inspect import Inspect
