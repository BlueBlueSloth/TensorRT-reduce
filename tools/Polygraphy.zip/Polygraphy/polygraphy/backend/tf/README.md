NOTE: The `tf` backend currently only supports TensorFlow 1.X.
