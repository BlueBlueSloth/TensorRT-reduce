# Examples

This directory includes various examples covering the Polygraphy [CLI](./cli), [Python API](./api), and [development practices](./dev).

The paths used in each example assume that the example is being run from within that example's directory.
