# Polygraphy Reshape Destroyer

An example `polygraphy run` extension module that can replace no-op `Reshape`s in an ONNX
model with `Identity` nodes and run inference.
