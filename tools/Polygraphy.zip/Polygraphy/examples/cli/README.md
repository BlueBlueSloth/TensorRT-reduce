# Polygraphy CLI Examples

This directory includes examples that use the Polygraphy CLI.
For examples of the Python API, see the [api](../api/) directory instead.

You may find the [CLI User Guide](../../polygraphy/tools/) useful to navigate the CLI examples.
